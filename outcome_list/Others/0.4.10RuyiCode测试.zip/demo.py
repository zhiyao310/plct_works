def add(a: int, b: int) -> int:
    return a + b


def divide(a: float, b: float) -> float:
    return a / b


# 计算两个正整数的最大公约数
def gcd(a, b):
    while b != 0:
        a, b = b, a % b
    return a


def main() -> None:
    print(add(2, 3))


if __name__ == "__main__":
    main()
