function add(a, b) {
  return a + b;
}

function main() {
  console.log(add(2, 3));
}

main();
